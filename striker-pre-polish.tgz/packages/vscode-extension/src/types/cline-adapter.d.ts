declare module 'cline-adapter';
